import express from 'express';
import multer from 'multer';
import * as contentController from '../controllers/contentControlller';

const contentRoutes = express.Router();
const upload = multer();

contentRoutes.post('/upload', upload.single('file'), contentController.upload);

module.exports.contentRoutes = contentRoutes;