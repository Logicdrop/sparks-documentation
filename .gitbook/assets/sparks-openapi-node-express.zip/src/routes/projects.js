import express from 'express';
import * as projectController from '../controllers/projectsController';

const projectRoutes = express.Router();

projectRoutes.put('/', projectController.createProject);
projectRoutes.patch('/', projectController.updateProject);
projectRoutes.get('/list', projectController.listProjects);
projectRoutes.delete('/:project', projectController.deleteProject);

module.exports.projectRoutes = projectRoutes;