import { ProjectServicesApi } from '@logicdrop/sparks-openapi-nodejs';
import { getToken } from '../utilities';

exports.listProjects = async (req, res, next) => {
  const projectService = new ProjectServicesApi(process.env.API_URL);
  let token = await getToken();

  const headers = {
    'Authorization': `Bearer ${token}`
  };

  try {
    const response = await projectService.listProjects(process.env.CLIENT, { headers });
    res.send(response.body);
  }
  catch(error) {
    next(error);
  }
}

exports.createProject = async (req, res, next) => {

  // Sample body
  // {
  //   "name": "string",
  //   "version": "string",
  //   "description": "string",
  //   "tags": [
  //     "string"
  //   ],
  //   "properties": {
  //     "property1": { },
  //     "property2": { }
  //   }
  // }

  const projectService = new ProjectServicesApi(process.env.API_URL);
  let token = await getToken();

  const headers = {
    'Authorization': `Bearer ${token}`
  };

  try {
    const response = await projectService.saveProject(process.env.CLIENT, req.body, { headers });

    res.send(response.body);
  }
  catch(error) {
    next(error);
  }
}

exports.updateProject = async (req, res, next) => {

  // Sample Body
  // -ids is only required field.
  // NOTE: ids is an array
  // {
  //   "ids": ["5cc07a8f7a1a0f00080a2081"],
  //   "name": "My project",
  //   "properties": {
  //       "test": "test"
  //   },
  //   "tags": [
  //       "x",
  //       "y",
  //       "z"
  //   ]
  // }

  const projectService = new ProjectServicesApi(process.env.API_URL);
  let token = await getToken();

  const headers = {
    'Authorization': `Bearer ${token}`
  };

  try {
    const response = await projectService.updateProject(process.env.CLIENT, req.body, { headers });

    res.send(response.response.body);
  }
  catch(error) {
    next(error);
  }
}

exports.deleteProject = async (req, res, next) => {

  // Project will be the artifact in the Project object

  const projectService = new ProjectServicesApi(process.env.API_URL);
  let token = await getToken();

  const headers = {
    'Authorization': `Bearer ${token}`
  };

  try {
    const response = await projectService.deleteProject(process.env.CLIENT, req.params.project, { headers });
    res.send(response.response.body);
  }
  catch(error) {
    next(error);
  }
}