import { ContentServicesApi } from '@logicdrop/sparks-openapi-nodejs';
import { getToken } from '../utilities';

exports.upload = async (req, res, next) => {
  const project = 'my-simple-project';

  const contentService = new ContentServicesApi(process.env.API_URL);

  const token = await getToken();

  const headers = {
    'Content-Type': 'multipart/form-data',
    'Authorization': `Bearer ${token}`
  };

  contentService.uploadContent(process.env.CLIENT, project, null, null, req.file, { headers })
    .then(response => {
      res.send(response.body);
    })
    .catch(error => {
      next(error);
    });
} 