import request from 'request';

exports.getToken = () => {
  return new Promise((resolve, reject) => {
    request.post(`https://${process.env.CLIENT_ID}:${process.env.CLIENT_SECRET}@${process.env.API_URL.replace('https://', '')}/oauth/token?grant_type=client_credentials`, { json: true }, (err, res, body) => {
      if (body && body.access_token) {
        resolve(body.access_token);
      }
      else {
        reject(new Error('Could not get Sparks API token.'));
      }
    });
  });
}