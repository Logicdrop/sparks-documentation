import express from 'express';
import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import { projectRoutes } from './routes/projects';
import { contentRoutes } from './routes/content';

// Add this to use environment variables inside your application.
dotenv.config();

// Initialize express application
const app = express();

// Used to properly parse the body of a request
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.send('Sparks example API is up!');
});

app.use('/projects', projectRoutes);
app.use('/content', contentRoutes);

app.use((error, req, res, next) => {
  res.status(500).send({ error: 'Something went wrong...' });
});

app.listen(3000, () => {
  console.log('App listening on port 3000...');
});