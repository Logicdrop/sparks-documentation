# Sparks OpenAPI NodeJS Example
This project is an example of how to implement the `sparks-openapi-nodejs` package into an Express server.

**NOTE:** This example is using Babel and ES6 syntax

## Getting Started
In order to use `sparks-openapi-nodejs` you will need a connect to Logicdrop's public NPM respository. To do this, 
you will need to include a `.npmrc` file in the root of your project. This file should contain the following,

```
registry=https://depot.logicdrop.com/repository/npm-public/
_auth={jared not sure where this value comes from}
```

You can receive your client secret from the Sparks Portal once you have set up an account. Once this file is in
place you can run the following command to import the package,

```
npm install @logicdrop/sparks-openapi-nodejs
```

## Accessing API Calls
In order to access the API, you must generate a JWT token first. This sample project contains a utility function that
peforms getting a token for the Sparks API.

## Getting Sample Server Working

```
npm install
```

Once you have installed the dependencies, you will also need to include a `.env` file in the root of your project. This file should
contain the following values,

```
API_URL=https://api.logicdrop.io
CLIENT=******************
CLIENT_ID=******************
CLIENT_SECRET=******************
```

Replacing the star lines with your values. Finally all you will have to do is run the following command to boot up the server,

```
npm run start
```
